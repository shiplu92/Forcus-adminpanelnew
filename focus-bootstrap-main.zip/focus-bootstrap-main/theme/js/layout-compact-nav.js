(function($) {
    "use strict"
    
    new quixSettings({
        sidebarStyle: "compact"
    });


})(jQuery);
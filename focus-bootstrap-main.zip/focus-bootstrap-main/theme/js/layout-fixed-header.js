(function($) {
    "use strict"

    new quixSettings({
        headerPosition: "fixed",
    });


})(jQuery);